function [Xsern,simbolos_tx,datos_tx,f_datos]=transmitter(display)
% function [Xsern,simbolos_tx,datos_tx,f_datos]=transmitter(NB,NFFT,M,NG,NCP,NUSED,npilot,NPILOT,ind_pil,ind_npil,display)
global M NFFT NG NUSED NPILOT NB NDATA NCP ind_pil ind_npil ini_phase FACTOR npilot NK no_train_block TG Ts fm time
%%TRANSMISOR OFDM
%PARAMETROS 
    NDATA=NUSED-NPILOT; %Numero de subportadoras de datos (sin contar pilotos) 
%DATOS Y PILOTOS
    %Vectores de datos (enteros aleatorios)
    training=randi([0 1],1,NUSED*(length(1:NK:NB))); %Enteros para bloques training (tama�o Nused)
    pilotos=randi([0 1],1,NPILOT*(length(no_train_block))); %Enteros para las pilotos (tama�o NPILOT)
    datos_tx=randi([0 M-1],1,NDATA*(length(no_train_block))); %Generacion enteros a transmitir
%MAPEO
    %Factores normalizaci�n para mapeos: QPSK, 16QAM Y 64QAM
    FACTORS=[0 2 0 10 0 42];
    FACTOR=sqrt(1/FACTORS(log2(M)));
    %Modulacion de los vectores de datos (QPSK datos, BPSK pilotos) 
    f_training=2*training-1; %Entrenamiento: BPSK
    f_datos=FACTOR*qammod(datos_tx,M,ini_phase,'gray'); %Datos: QPSK
    f_pilotos=2*pilotos-1; %Pilotos: BPSK  
    %Forma matricial: (Filas: simbolos, Columnas: Numero de bloque)
    f_training=reshape(f_training,[],length(1:NK:NB)); 
    f_datos=reshape(f_datos,[],length(no_train_block)); 
    f_pilotos=reshape(f_pilotos,[],length(no_train_block)); 
%SIMBOLOS ENTRENAMIENTO
    simbolos_tx=zeros(NUSED,NB);    
    %Elegir o no la opci�n training y que sea cada NK simbolos
    simbolos_tx(:,1:NK:NB)=f_training(:,1)*ones(1,length(1:NK:NB)); 
    simbolos_tx(:,2:NK:NB)=f_training(:,2)*ones(1,length(1:NK:NB)); 
%SIMBOLOS DATOS
    simbolos_tx(ind_npil(1:ceil(NDATA/2)),no_train_block)=f_datos(1:ceil(NDATA/2),:);
    simbolos_tx(ind_npil(ceil(NDATA/2)+1:NDATA),no_train_block)=f_datos(ceil(NDATA/2)+1:NDATA,:);
    simbolos_tx(ind_pil,no_train_block)=f_pilotos;
%INSERCION DC Y GUARDAS
    simbolosp=[zeros(ceil(NG/2),NB); simbolos_tx; zeros(ceil(NG/2),NB)]; %Guardas: NG a ambos lados (elegido para rellenar la ifft NFFT)
    simbolos_ifft=[zeros(1,NB); simbolosp; zeros(1,NB); flipud(conj(simbolosp));]; %Reordenamiento Hermitico
%IFFT
    Xo=ifft(simbolos_ifft,NFFT); %IFFT: NFFT  muestras  
%INSERCION CP
    Xs=[Xo(end-(NCP-1):end,:); Xo]; %Inserci�n CP: NCP muestras
%CONVERSI�N PARALELO SERIE    
    Xsern=reshape(Xs,1,[]); %Se�al que se env�a al receptor 
    time=linspace(0,Ts,length(Xsern));
    TG_MAT=zeros(NB,TG);
    %Se�al auxiliar para ver los simbolos OFDM separados
    Xsern_new=reshape(Xsern,[],NFFT+NCP); %Lo divido en cada uno de los simbolos
    Xsern_new=[Xsern_new TG_MAT];
    Xsern_new=reshape(Xsern_new',1,[]); %Se�al para visualizar s�mbolo a s�mbolo
    time_new=linspace(0,Ts,length(Xsern_new));
%MODULACI�N DE SE�AL SERIE 
%     fm=1e6;
%     1000,length(Xsern)%     
%     Modulada=Xsern.*cos(2*pi*fm*time);
%     time_mod=linspace(0,Ts,length(Modulada));
    if (display==1)
         %figure(1),stem(real(f_datos)),title(['Datos QPSK a modular en OFDM'])
         %figure(2),scatterplot(simbolos_tx(:,3)),title(['Constelaci�n Transmitida'])
         figure(3), stem(real(simbolosp(:,3))),title(['Parte real de un bloque de datos y pilotos intercalados, con ' num2str(npilot) ' subportadoras entre pilotos'])  
         %figure(4),plot(real(simbolos_ifft(:,3))) ,title(['Parte real simbolos antes de la IFFT'])
         figure(5),plot((-NFFT/2:NFFT/2-1)/NFFT,fftshift(abs(fft(Xo(:,3),NFFT)))), title('Espectro de un s�mbolo OFDM antes del canal')
         figure(6),plot(time,Xsern), title('S�mbolos OFDM en el tiempo (s�mbolos seguidos tal como se env�an al AWG): L(NFFT+NCP)')
         figure(7),plot(time_new,Xsern_new), title('S�mbolos OFDM en el tiempo(con intervalo guarda temporal nulo): L(NFFT+NCP)')
%          figure(8),plot(time_mod,Modulada), title('S�mbolos OFDM en el tiempo modulados')
%          figure(9),plot((-NFFT/2:NFFT/2-1)/NFFT,fftshift(abs(fft(Modulada,NFFT)))),title('Espectro de un s�mbolo OFDM subido en frecuencia antes del canal')
    end

   
