clear, close all, clc
global npilot M NFFT NG NUSED NPILOT NB NDATA NK G NCP Ts FD ind_pil ind_npil snr no_train_block TG Ts Fs_AWG
ini_phase=0;
npilot=10; %Cada npilot subportadoras hay una piloto
M=4; %Sera QPSK la modulaci�n de los datos
NG=5; % Numero de subportadoras de guarda (por cada lado habran NG/2)
W=528e6; %Ancho de banda
TG=NG/W %Numero de muestras de guarda en el tiempo (entre dos simbolos)
NFFT=256; %NFFT>NG
NUSED=(NFFT-2*NG-2)/2 %Numero de subportadoras utilizadas (pilotos+datos) (NFFT ha de ser mayor a 2*NG+2)
NPILOT=length(1:npilot+1:NUSED) %EL numero de pilotos se calcula a partir de saber cada cuantas portadoras hay piloto
TFFT=NFFT/W
snr=15;
NB=60; % Numero de bloques OFDM (2 de entrenamiento y los demas con datos+pilotos intercalados)
NK=10; %Cada cuantos simbolos se vuelven a enviar 2 simbolos de training
no_train_block=setxor(setxor(1:NB,1:NK:NB),2:NK:NB);
Fs_AWG=1.25e9; %AWG data rate
NDATA=NUSED-NPILOT %Numero de subportadoras de datos (sin contar pilotos)
G=1/4;
NCP=ceil(G*NFFT);% Muestras prefijo ciclico  
TCP=NCP/W
TSYM=TFFT+TCP+TG
DATARATE=Fs_AWG*log2(M)*(NDATA/(NCP+NFFT))*((length(no_train_block))*NDATA/(NB*NUSED)); %N es el numero de bits que transmito en mi simulacion (los de entrenamiento no se cuentan ya que no tienen la misma codificacion)
Ts=1/Fs_AWG; %Para el canal
FD=0;
ind_pil=1:npilot+1:NUSED;  %Indices donde iran las pilotos intercaladas
ind_npil=setxor(1:NUSED,ind_pil); % Indices donde no iran pilotos (datos)
display=1;
[Xsern,simbolos_tx,datos_tx,f_datos]=transmitter(display);
BER=receiver(Xsern,display,simbolos_tx,datos_tx,f_datos)

%It creates a binary file to be sent to the N6030 AWG
% [errorcode, errorcode_description] = agt_awg_savebin('signal',Xsern);
%[PSD,df]=cp0301_PSD(I,fs,'r');

