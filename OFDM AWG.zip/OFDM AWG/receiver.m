function BER=receiver(Xsern,display,simbolos_tx,datos_tx,f_datos)
global M NFFT NG NUSED NPILOT NB NDATA NCP ind_pil ind_npil ini_phase FACTOR snr NK no_train_block
%VARIABLES
    H_CFR=zeros(NUSED,NB);
    H_piloto=zeros(NPILOT,length(no_train_block));
%DEMODULACI�N DE SE�AL SERIE 
    %Multiplicar por se�al moduladora
%      Modulada_rx=Modulada.*cos(2*pi*fm*time);
%      time_rx=linspace(0,Ts,length(Modulada_rx));   
    %Filtrar paso bajo
%     Wn=4*pi*fm/Fs_AWG
%     [B,A] = BUTTER(4,Wn,'low'); %designs a lowpass filter.
%     figure(1000),freqz(B,A)
%     Modulada_fil=filter(B,A,Modulada_rx);
%     time_fil=linspace(0,Ts,length(Modulada_fil)); 
%     Modulada_fil=Modulada_fil(1:NB*(NFFT+NCP));
%      1000,length(Modulada_fil)
%CONVERSI�N SERIE PARALELO
    Xparn=reshape(Xsern,[],NB);
%EXTRACCION CP
    Xor=Xparn(NCP+1:end,:);
%FFT
    simbolos_fft=fft(Xor,NFFT);
%EXTRACCION BANDAS GUARDA Y DC   
    simbolos_pr=simbolos_fft(2:(NUSED+NG),:);  
    simbolos_rx=simbolos_pr((NG/2)+1:(NUSED+ceil(NG/2)),:);
%ESTIMACION CANAL
    H_CFR(:,1:NK:end)=simbolos_rx(:,1:NK:end)./simbolos_tx(:,1:NK:end); %El canal con los simbolos de entrenamiento esta completo
    H_CFR(:,2:NK:end)=simbolos_rx(:,2:NK:end)./simbolos_tx(:,2:NK:end); %El canal con los simbolos de entrenamiento esta completo
    H_CFR(ind_pil,no_train_block)=simbolos_rx(ind_pil,no_train_block)./simbolos_tx(ind_pil,no_train_block);    
    H_pilot=H_CFR; %Esto es simplemente para representar
    H_piloto(:,1:length(no_train_block))=simbolos_rx(ind_pil,no_train_block)./simbolos_tx(ind_pil,no_train_block);
    H_CFR(:,no_train_block)=interpft(H_piloto(:,1:length(no_train_block)),NUSED); % H_CFR en todas las portadoras mediante interpolacion
    %Una vez se tiene la estimacion del canal , se tiene que extraer al
    %awgn de antes la guarda cp etc ver como hacerlo pues esta en la
    %frecuencia
    H_CFR_x=reshape(H_CFR,1,[]);
    simbolos_corr=simbolos_rx./H_CFR; %Correcci�n simbolos con H_CFR (a partir de pilotos) 
    simbolosnp=simbolos_corr(ind_npil,no_train_block); %quito los bloques de training y las pilotos intercaladas   
    simbolosnp_rx=reshape(simbolosnp,1,[]);
    simbolosnp_rx=simbolosnp_rx/FACTOR;
%PARAMETROS EVM Y MER DE LOS SIMBOLOS CORREGIDOS
    Diff=simbolosnp-f_datos;
    Env_I=real(simbolosnp);
    Env_Q=imag(simbolosnp);
    Inc_I=real(Diff);
    Inc_Q=imag(Diff);
    MAX=(abs((sqrt(M)-1)*(1+1j))).^2; %Potencia simbolo m�s exterior en QAM
    EVM(1:NDATA)=sqrt(mean(((Inc_I').^2+(Inc_Q').^2)/MAX))*100; %EVM(%) por portadora 
    EVM_dB=20*log10(EVM/100); %EVM en dB por portadora
    EVM_MEAN_dB=mean(EVM_dB);
    EVM_MAT_dB=sqrt((((Inc_I').^2+(Inc_Q').^2)/MAX))*100;
    MER=10*log10(mean(((Env_I').^2+(Env_Q').^2)./((Inc_I').^2+(Inc_Q').^2)));
    MER_MAT=10*log10((((Env_I').^2+(Env_Q').^2)./((Inc_I').^2+(Inc_Q').^2)));
    MER_MEAN=mean(MER);
%DEMODULACION
    datos_rx=qamdemod(simbolosnp_rx,M,ini_phase,'gray'); 
    datos_rx=datos_rx(:)';
    Nerrors=length(find(datos_tx-datos_rx));
    BER=Nerrors/length(datos_tx);
        if display==1
%            figure(10),plot(time,Modulada), title('S�mbolos OFDM en el tiempo RX sin demodular') 
%            figure(11),plot(time_rx,Modulada_rx), title('S�mbolos OFDM en el tiempo RX tras multiplicar por coseno para recibir')
%            figure(12),plot(time_fil,Modulada_fil), title('S�mbolos OFDM en el tiempo RX tras demodular')
           figure(13),plot((-NFFT/2:NFFT/2-1)/NFFT,fftshift(abs(fft(Xor(:,3),NFFT)))), title('Espectro de un s�mbolo OFDM despu�s del canal')
           figure(14),h=stem(abs(H_pilot(:,3)),'fill');set(h,'MarkerFaceColor','red'),hold on, stem(abs(H_CFR(:,3))),legend('Hpiloto','HCFR'),hold off 
           figure(15),plot(real(simbolos_rx(:,3)),imag(simbolos_rx(:,3)),'.'),title(['Constelaci�n Recibida'])
           figure(16),stem(real(simbolos_rx(:,3))),title(['Parte real de los Simbolos antes de igualar']) 
%            figure(17),plot((abs(H_CFR_x)),'r-'),hold on,plot((abs(Hf))) ,legend('H_e_s_t_i_m_a_d_a_[_k_]','H_r_e_a_l_g_e_n_e_r_a_d_a_[_k_]'),title(['Canal real y canal estimado por interpolaci�n']),hold off
           figure(18),plot(real(simbolos_rx),imag(simbolos_rx),'y*'),legend('Sin ecualizar'),hold on,plot(real(simbolos_corr),imag(simbolos_corr),'r*'),legend('Ecualizados'),xlabel([' PARAMETROS SIMBOLOS CORREGIDOS: SNR(dB): ' num2str(snr) ', EVM(dB): ' num2str(EVM_MEAN_dB) ', MER(dB): ' num2str(MER_MEAN)])
        end
end  

